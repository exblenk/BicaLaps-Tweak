# AIVideoUnlock — Theos Tweak

Persistent .dylib version of `unlock-deep.js`. Once installed on a jailbroken device, it auto-loads into `com.saidul.aivideo` at launch — no Frida needed.

## Layers

| Layer | What |
|---|---|
| L1 | Apple receipt forger + Firestore document patcher (`NSJSONSerialization`) |
| L2 | UserDefaults premium-key override (8 keys) |
| L3 | `FIRRemoteConfig configValueForKey:` swizzled (dynamic — only if Firebase linked) |
| L4 | `NSURLSession` response rewriter (5 gate patterns) |
| L5 | `CCCrypt` observer (off by default — `#define ENABLE_CC_OBSERVER 1` to enable) |
| L6 | SSL pinning bypass — `SecTrustEvaluate*` + AFNetworking + TrustKit |
| L7 | Auto-trigger `restoreCompletedTransactions` on launch |

## Prerequisites

- Theos installed (https://theos.dev/docs/installation-macos)
- `$THEOS` env var set
- Jailbroken iOS device or simulator with substrate / substitute / ellekit
- iOS SDK 14.0+ in your Theos SDKs

## Build

```bash
cd Projects/aivideo-tweak

# build .deb
make package FINALPACKAGE=1

# build + install over SSH (set THEOS_DEVICE_IP / THEOS_DEVICE_PORT first)
make package install FINALPACKAGE=1
```

The `.deb` ends up in `./packages/`.

## Install manually

```bash
# copy .deb to device, then:
dpkg -i com.unlock.aivideo_1.0.0_iphoneos-arm.deb

# respring
killall -9 SpringBoard
```

## Watch logs

```bash
# on device (e.g. via Filza Terminal or SSH)
idevicesyslog | grep AIUnlock
# or
oslog | grep AIUnlock
```

Expected on launch:
```
[AIUnlock] ════════════════════════════════════════════
[AIUnlock]  AIVideoUnlock loaded into com.saidul.aivideo
[AIUnlock] [init] FIRRemoteConfig.configValueForKey: swizzled
[AIUnlock] [init] SSL pinning bypass armed
[AIUnlock] [init] all layers armed
[AIUnlock] [HIT] Apple receipt status=0 hasProducts=0
[AIUnlock] [PATCH] receipt → status=0 + yearly+weekly @2099
[AIUnlock] [TRIGGER] restoreCompletedTransactions called
```

## Switch toggles

In `Tweak.x` top:
```objc
#define ENABLE_CC_OBSERVER  0   // 1 = log AES/HMAC ops (verbose)
#define ENABLE_NET_LOG      1   // 0 = silent (less log noise)
#define ENABLE_PIN_BYPASS   1   // 0 = leave pinning intact
```

## Target a different app

1. Edit `control` → change `Package` name if you want
2. Edit `AIVideoUnlock.plist` → `Bundles = ( "com.your.target" );`
3. Edit `Makefile` → `INSTALL_TARGET_PROCESSES = YourBinaryName` (the executable name inside the .app)
4. Update product IDs in `Tweak.x` top (`PRODUCT_YEAR`, `PRODUCT_WEEK`)
5. Adjust gate patterns + premium key regex if needed

## Uninstall

```bash
dpkg -r com.unlock.aivideo
killall -9 SpringBoard
```

## Notes

- Built with arm64 + arm64e — works on iOS 14+
- Uses Theos `%hook` for ObjC + `MSHookFunction` for C symbols (requires substrate / substitute / ellekit)
- For rootless jailbreaks (Dopamine / palera1n), Theos handles rootless automatically when `THEOS_PACKAGE_SCHEME=rootless` is set:
  ```bash
  export THEOS_PACKAGE_SCHEME=rootless
  make package FINALPACKAGE=1
  ```
